# Dicoding Map Stories (Vite)
Jalankan: `npm install` → `npm run dev`.
